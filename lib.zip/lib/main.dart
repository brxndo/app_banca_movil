import 'package:app_banca_virtual_movil_2/app/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  runApp(const ProviderScope(child: AppArquitecturaLimpia2()));
}
